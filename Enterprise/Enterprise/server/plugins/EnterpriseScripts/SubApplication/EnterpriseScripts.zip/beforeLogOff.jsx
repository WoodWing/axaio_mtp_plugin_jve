try
{
	alert( "*** BEFORE LOG OFF (system) ***" );
}
catch(E)
{
	alert( "ERROR: " + E.name + "\n\n" + E.message + "\n\nFound on line " + E.line );
}